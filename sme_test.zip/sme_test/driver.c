#include <time.h>
#include <stdio.h>
#include <unistd.h>


int sme_kernel(int x);

#define WARMUP_LOOP (1e9)
#define LOOP (1e7)
typedef int (*kernel_func_t)(int);

static double get_time(struct timespec *start, struct timespec *end){
    return end->tv_sec - start->tv_sec + (end->tv_nsec - start->tv_nsec) * 1e-9;
}

// 测试计时 API 准确性
static void test_timing() {
    struct timespec start, end;
    struct timespec sleep_time = {1, 2000000};  

    clock_gettime(CLOCK_MONOTONIC_RAW, &start);
    nanosleep(&sleep_time, NULL);
    clock_gettime(CLOCK_MONOTONIC_RAW, &end);

    double time_used = get_time(&start, &end);
    printf("test_timing: Expected time = 1.002 s, Actual time = %.6lf s\r\n", time_used);
}

static void test_single(kernel_func_t kernel_func, 
                        const int loop) {
    struct timespec start, end;
    double time_used = 0.0;
    
    kernel_func(WARMUP_LOOP);

    clock_gettime(CLOCK_MONOTONIC_RAW, &start);
    int ops_per_loop = kernel_func(loop);
    clock_gettime(CLOCK_MONOTONIC_RAW, &end);

    time_used = get_time(&start, &end);
    printf("time: %.6lf s\r\n", time_used);
    printf("perf: %.6lf GFlOPS\r\n", 
        (double)loop * ops_per_loop * 1e-9 / time_used);
}

int main() {
    test_timing();

    printf("SME fp32 MOP:\n");
    test_single(sme_kernel, LOOP);

}
